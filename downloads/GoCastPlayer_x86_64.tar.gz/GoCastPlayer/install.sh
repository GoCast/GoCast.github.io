#!/bin/bash

echo "GoCastPlayer Install: Plugin will be installed in ~/.mozilla/plugins"
mkdir -p ~/.mozilla
mkdir -p ~/.mozilla/plugins
cp npGCP_*.so ~/.mozilla/plugins/
echo "GoCastPlayer Install: Done"

